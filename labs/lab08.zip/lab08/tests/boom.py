test = {
  'name': 'Boom',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'answer': '6df5154157f2b5691f58df9227647660',
          'choices': [
            '1',
            'n',
            'log(n)',
            'n^2',
            'n^3',
            'n^4',
            'exponential'
          ],
          'hidden': False,
          'locked': True,
          'question': 'What is the order of growth in runtime for boom?'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}